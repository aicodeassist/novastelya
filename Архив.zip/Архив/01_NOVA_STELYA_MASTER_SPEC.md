# ТЕХНІЧНЕ ЗАВДАННЯ: NOVA STELYA

## Еталонна GEO/SEO архітектура 2026 — Next.js 16+

> **Версія:** 3.0 FINAL  
> **Стандарт:** Gold Standard 2026 — Maximum SEO · Edge Performance · AI-Ready  
> **Пріоритет №1:** SEO (технічне + контентне + GEO/AEO)

-----

## ЗМІСТ

1. [Технологічний стек](#1-технологічний-стек)
1. [Архітектура проєкту](#2-архітектура-проєкту)
1. [Структура URL](#3-структура-url)
1. [Файлова структура Next.js](#4-файлова-структура-nextjs)
1. [geo-matrix.ts — джерело правди](#5-geo-matrixts--джерело-правди)
1. [SEO: Metadata API](#6-seo-metadata-api)
1. [SEO: Schema.org JSON-LD](#7-seo-schemaorg-json-ld)
1. [SEO: Sitemap & Robots](#8-seo-sitemap--robots)
1. [i18n: мультимовність](#9-i18n-мультимовність)
1. [Система міст (City-in-a-Box)](#10-система-міст-city-in-a-box)
1. [Middleware: Edge Routing](#11-middleware-edge-routing)
1. [Компоненти та блоки сторінок](#12-компоненти-та-блоки-сторінок)
1. [Калькулятор і форми](#13-калькулятор-і-форми)
1. [Performance: Core Web Vitals](#14-performance-core-web-vitals)
1. [GEO/AEO: оптимізація для AI](#15-geoaeo-оптимізація-для-ai)
1. [API Routes](#16-api-routes)
1. [Критерії прийому (Acceptance Criteria)](#17-критерії-прийому-acceptance-criteria)
1. [Що НЕ робити](#18-що-не-робити)

-----

## 1. ТЕХНОЛОГІЧНИЙ СТЕК

```
Framework:        Next.js 16+ (App Router, React Server Components)
Language:         TypeScript 5.5+ (strict mode, no any)
Styling:          Vanilla CSS only + CSS Modules (тільки критичний CSS inline)
CMS:              Sanity v3 (headless, GROQ queries, typed)
Database:         PostgreSQL + Prisma (заявки, аналітика)
Cache:            Redis via Upstash (serverless, edge-compatible)
Images:           next/image + Cloudinary (WebP/AVIF auto-convert)
Fonts:            next/font/google (zero layout shift, self-hosted)
i18n:             next-intl 3.x
Schema:           schema-dts + JSON-LD (типізовані об'єкти)
Deployment:       Vercel (Edge Runtime) + Cloudflare CDN + R2
Analytics:        Vercel Analytics + GA4 server-side events
Monitoring:       Sentry (errors) + Vercel Speed Insights
```

**Заборонено використовувати:**

- jQuery, Bootstrap, Tailwind, любі CSS фреймворки
- `pages/` router — тільки `app/` router
- `getServerSideProps` / `getStaticProps` — застарілі патерни
- `localStorage` для збереження міста (тільки cookie)
- Будь-які `catch-all` роути `[...slug]` як основний патерн

-----

## 2. АРХІТЕКТУРА ПРОЄКТУ

### Концепція: Data-Driven + Edge-First

```
┌─────────────────────────────────────────────────┐
│              geo-matrix.ts                       │
│   (єдине джерело правди: міста + послуги)        │
└──────────────────┬──────────────────────────────┘
                   │ generateStaticParams()
         ┌─────────┴─────────┐
         │                   │
    ┌────▼────┐         ┌────▼────────────────┐
    │ /[city] │         │ /[city]/[service]   │
    │ Сторінка│         │ Авто-генерація всіх │
    │  міста  │         │ комбінацій          │
    └────┬────┘         └────┬────────────────┘
         │                   │
    ┌────▼───────────────────▼────┐
    │     Edge CDN (Cloudflare)   │
    │   TTFB < 50ms worldwide     │
    └─────────────────────────────┘
```

### Принципи рендерингу:

|Тип сторінки   |Метод    |Revalidate|
|---------------|---------|----------|
|Головна        |SSG + ISR|3600s     |
|Сторінки послуг|SSG + ISR|3600s     |
|Сторінки міст  |SSG + ISR|3600s     |
|Місто × Послуга|SSG + ISR|3600s     |
|Блог (список)  |SSG + ISR|1800s     |
|Блог (стаття)  |SSG + ISR|on-demand |
|Портфоліо      |SSG + ISR|on-demand |
|Прайс          |SSG + ISR|900s      |

-----

## 3. СТРУКТУРА URL

### Правила:

- `trailingSlash: false` — ЗАВЖДИ без слешеа на кінці
- Українська мова: БЕЗ префікса (`/`)
- Російська мова: з префіксом `/ru`
- При заході без слеша → **301 redirect** на версію зі слешем
- Всі URL в нижньому регістрі, латиниця, дефіси

### Повна карта URL:

```
━━━ ГОЛОВНА ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
UK: novastelya.com/
RU: novastelya.com/ru

━━━ КАТАЛОГ ПОСЛУГ (Матеріали) ━━━━━━━━━━━━━━━━━━━━
novastelya.com/matte-ceilings
novastelya.com/glossy-ceilings
novastelya.com/satin-ceilings
novastelya.com/fabric-ceilings

━━━ КАТАЛОГ ПОСЛУГ (Конструкції) ━━━━━━━━━━━━━━━━━━
novastelya.com/shadow-ceilings
novastelya.com/floating-ceilings
novastelya.com/slotted-ceilings
novastelya.com/carved-ceilings
novastelya.com/double-level-ceilings

━━━ ОСВІТЛЕННЯ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
novastelya.com/light-lines
novastelya.com/track-lighting
novastelya.com/backlight
novastelya.com/starry-sky

━━━ КІМНАТИ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
novastelya.com/kitchen-ceilings
novastelya.com/bathroom-ceilings
novastelya.com/bedroom-ceilings
novastelya.com/living-room-ceilings

━━━ КОНТЕНТ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
novastelya.com/portfolio
novastelya.com/portfolio[slug]/
novastelya.com/prices
novastelya.com/faq
novastelya.com/blog
novastelya.com/blog[slug]
novastelya.com/blog/category[category]/
novastelya.com/contacts

━━━ МІСТА (Регіональні хаби) ━━━━━━━━━━━━━━━━━━━━━
novastelya.com/[city]                          → Хаб міста
novastelya.com/[city]/matte-ceilings           → Послуга в місті
novastelya.com/[city]/glossy-ceilings          → ...
novastelya.com/[city]/prices                   → Регіональний прайс
novastelya.com/[city]/portfolio                → Регіональне портфоліо
novastelya.com/[city]/faq                      → Регіональний FAQ

━━━ СЛУЖБОВІ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
novastelya.com/sitemap.xml                      (авто-генерація)
novastelya.com/robots.txt                       (динамічний)
novastelya.com/manifest.webmanifest            (PWA)
```

### Приклади з russian locale:

```
novastelya.com/ru
novastelya.com/ru/matte-ceilings
novastelya.com/ru/kyiv
novastelya.com/ru/kyiv/matte-ceilings
```

-----

## 4. ФАЙЛОВА СТРУКТУРА NEXT.JS

```
nova-stelya/
│
├── app/
│   ├── layout.tsx                    # Root: <html>, hreflang x-default, OG global
│   ├── not-found.tsx                 # Global 404
│   ├── sitemap.ts                    # Динамічний sitemap: всі локалі × міста × послуги
│   ├── robots.ts                     # robots.txt per env
│   ├── manifest.ts                   # PWA manifest
│   │
│   └── [locale]/                     # "uk" | "ru"
│       ├── layout.tsx                # lang attr + hreflang + OG locale + LocalBusiness
│       ├── page.tsx                  # Головна
│       ├── not-found.tsx             # Locale 404
│       │
│       ├── (catalog)/                # Route group — не впливає на URL
│       │   ├── matte-ceilings/
│       │   │   └── page.tsx
│       │   ├── glossy-ceilings/
│       │   │   └── page.tsx
│       │   ├── satin-ceilings/
│       │   │   └── page.tsx
│       │   ├── fabric-ceilings/
│       │   │   └── page.tsx
│       │   ├── shadow-ceilings/
│       │   │   └── page.tsx
│       │   ├── floating-ceilings/
│       │   │   └── page.tsx
│       │   ├── slotted-ceilings/
│       │   │   └── page.tsx
│       │   ├── carved-ceilings/
│       │   │   └── page.tsx
│       │   └── double-level-ceilings/
│       │       └── page.tsx
│       │
│       ├── (lighting)/               # Route group
│       │   ├── light-lines/
│       │   │   └── page.tsx
│       │   ├── track-lighting/
│       │   │   └── page.tsx
│       │   ├── backlight/
│       │   │   └── page.tsx
│       │   └── starry-sky/
│       │       └── page.tsx
│       │
│       ├── (rooms)/                  # Route group
│       │   ├── kitchen-ceilings/
│       │   │   └── page.tsx
│       │   ├── bathroom-ceilings/
│       │   │   └── page.tsx
│       │   ├── bedroom-ceilings/
│       │   │   └── page.tsx
│       │   └── living-room-ceilings/
│       │       └── page.tsx
│       │
│       ├── portfolio/
│       │   ├── page.tsx
│       │   └── [slug]/
│       │       └── page.tsx          # generateStaticParams від Sanity
│       │
│       ├── prices/
│       │   └── page.tsx
│       │
│       ├── faq/
│       │   └── page.tsx
│       │
│       ├── blog/
│       │   ├── page.tsx
│       │   ├── [slug]/
│       │   │   └── page.tsx
│       │   └── category/
│       │       └── [category]/
│       │           └── page.tsx
│       │
│       ├── contacts/
│       │   └── page.tsx
│       │
│       └── [city]/                   # Динамічний — міста з geo-matrix.ts
│           ├── layout.tsx            # City-level: GeoMetaTags + LocalBusiness
│           ├── page.tsx              # Хаб міста
│           ├── prices/
│           │   └── page.tsx
│           ├── portfolio/
│           │   └── page.tsx
│           ├── faq/
│           │   └── page.tsx
│           └── [service]/            # Послуга в місті
│               └── page.tsx          # generateStaticParams: всі активні послуги
│
├── app/api/
│   ├── contact/
│   │   └── route.ts                  # Заявка → Telegram + Email
│   ├── revalidate/
│   │   └── route.ts                  # Webhook від Sanity → on-demand ISR
│   └── geo/
│       └── route.ts                  # Визначення міста по IP (Edge)
│
├── src/
│   ├── components/
│   │   ├── seo/
│   │   │   ├── LocalBusinessSchema.tsx
│   │   │   ├── ServiceSchema.tsx
│   │   │   ├── BreadcrumbSchema.tsx
│   │   │   ├── FAQSchema.tsx
│   │   │   ├── ArticleSchema.tsx
│   │   │   ├── ProductSchema.tsx
│   │   │   ├── ImageGallerySchema.tsx
│   │   │   ├── HreflangTags.tsx
│   │   │   └── GeoMetaTags.tsx
│   │   │
│   │   ├── ui/                       # Базові: Button, Card, Modal, Input, Badge
│   │   ├── layout/                   # Header, Footer, Breadcrumb, CitySelector
│   │   └── sections/                 # Hero, CatalogGrid, Benefits, PriceTable,
│   │                                 # Portfolio, Calculator, CTA, FAQ, Reviews
│   │
│   ├── config/
│   │   ├── geo-matrix.ts             # ⭐ ЄДИНЕ ДЖЕРЕЛО ПРАВДИ
│   │   ├── services.config.ts        # Всі послуги + slug + SEO метадані
│   │   ├── locales.config.ts         # uk (default) + ru
│   │   ├── seo.config.ts             # Глобальні SEO дефолти
│   │   └── page-blocks.config.ts     # Які блоки на яких сторінках
│   │
│   ├── lib/
│   │   ├── metadata.ts               # generatePageMetadata() — універсальна
│   │   ├── schema.ts                 # Фабрики JSON-LD об'єктів
│   │   ├── sitemap.ts                # URL-генератори для sitemap
│   │   ├── i18n.ts                   # next-intl helpers
│   │   └── sanity.ts                 # Typed GROQ queries
│   │
│   └── messages/
│       ├── uk.json                   # Всі переклади — українська
│       └── ru.json                   # Всі переклади — російська
│
├── middleware.ts                     # next-intl routing + city cookie + bot detect
├── next.config.ts                    # trailingSlash, images, headers, redirects
├── i18n.config.ts                    # next-intl конфіг
```

src/seo/
├── index.ts              ← единственная точка импорта для всего проекта
│
├── metadata.ts           ← generatePageMetadata() + buildCanonical()
│                            + buildHreflang() + OG + Twitter
│                            (~150 строк, всё в одном месте)
│
├── schema/
│   ├── local-business.ts ← LocalBusiness + GeoCoordinates
│   ├── service.ts        ← Service + Offer
│   ├── faq.ts            ← FAQPage + Question/Answer
│   ├── article.ts        ← Article + Person (author)
│   ├── breadcrumb.ts     ← BreadcrumbList
│   └── index.ts          ← SchemaScript injector + реэкспорт
│
├── sitemap.ts            ← всё в одном: static + cities + blog + portfolio
│                            (~120 строк)
│
├── robots.ts             ← 20 строк, отдельный файл оправдан (Next.js требует)
│
├── geo.ts                ← GeoMetaTags компонент + local-seo хелперы
│                            (~60 строк)
│
├── faq-content.ts        ← универсальные FAQ без city-спама
│
└── constants.ts          ← SITE_URL, SITE_NAME, SEO_DEFAULTS


-----

## 5. GEO-MATRIX.TS — ДЖЕРЕЛО ПРАВДИ

```typescript
// src/config/geo-matrix.ts
// ⭐ ЄДИНИЙ ФАЙЛ ДЛЯ УПРАВЛІННЯ ВСІМ САЙТОМ

export type CityConfig = {
  slug: string;
  uk: string;                    // Назва міста українською
  ru: string;                    // Назва міста російською
  region: string;                // ISO код регіону (UA-30)
  active: boolean;               // false = місто не генерується
  isPrimary?: boolean;           // Головний офіс
  phone: string;
  phone0800?: string;            // Безкоштовний номер
  address: string;
  addressRu: string;
  coordinates: {
    lat: number;
    lon: number;
  };
  priceModifier: number;         // 1.0 = базова ціна
  landmarks: string[];           // ЖК для GEO/AEO контенту
  officeHours: string;
  managerId?: string;            // ID менеджера для Schema
};

export const cities: CityConfig[] = [
  {
    slug: "kyiv",
    uk: "Київ",
    ru: "Киев",
    region: "UA-30",
    active: true,
    isPrimary: true,
    phone: "+380 44 000-00-00",
    phone0800: "0 800 000-000",
    address: "вул. Хрещатик, 1, Київ",
    addressRu: "ул. Крещатик, 1, Киев",
    coordinates: { lat: 50.4501, lon: 30.5234 },
    priceModifier: 1.0,
    landmarks: ["ЖК Файна Таун", "ЖК Комфорт Таун", "ЖК Rybalsky"],
    officeHours: "Пн-Сб 9:00-20:00",
  },
  {
    slug: "dnipro",
    uk: "Дніпро",
    ru: "Днепр",
    region: "UA-12",
    active: true,
    phone: "+380 56 000-00-00",
    address: "просп. Яворницького, 1, Дніпро",
    addressRu: "просп. Яворницкого, 1, Днепр",
    coordinates: { lat: 48.4647, lon: 35.0462 },
    priceModifier: 0.9,
    landmarks: ["ЖК Салют", "ЖК Panorama City"],
    officeHours: "Пн-Сб 9:00-19:00",
  },
  {
    slug: "kharkiv",
    uk: "Харків",
    ru: "Харьков",
    region: "UA-63",
    active: true,
    phone: "+380 57 000-00-00",
    address: "пл. Свободи, 1, Харків",
    addressRu: "пл. Свободы, 1, Харьков",
    coordinates: { lat: 49.9935, lon: 36.2304 },
    priceModifier: 0.88,
    landmarks: ["ЖК Журавлі", "ЖК Нові Будинки"],
    officeHours: "Пн-Сб 9:00-19:00",
  },
  // ✅ ДОДАТИ НОВЕ МІСТО = 1 ОБ'ЄКТ НИЖЧЕ:
  // { slug: "odesa", uk: "Одеса", ru: "Одесса", active: false, ... }
  // Змінити active: false → true — і всі сторінки з'являться автоматично
];

// Активні міста — використовується в generateStaticParams
export const activeCities = cities.filter(c => c.active);
export type CitySlug = typeof cities[number]["slug"];
export function getCityBySlug(slug: string) {
  return cities.find(c => c.slug === slug) ?? null;
}
```

-----

## 6. SEO: METADATA API

### Універсальна функція generatePageMetadata

```typescript
// src/lib/metadata.ts

type MetadataParams = {
  page: ServiceSlug | "home" | "portfolio" | "prices" | "faq" | "blog" | "contacts";
  city?: CityConfig;
  locale: "uk" | "ru";
  slug?: string;       // для blog/portfolio
  overrides?: Partial<Metadata>;
};

export function generatePageMetadata({
  page, city, locale, slug, overrides
}: MetadataParams): Metadata {
  const t = getTranslations(locale);
  const cityName = city?.[locale] ?? "";
  const baseUrl = "https://novastelya.com";

  // Title: унікальний для кожної комбінації
  const title = city
    ? `${t.services[page].title} у ${cityName} — ціни, фото | NOVA STELYA`
    : `${t.services[page].title} — NOVA STELYA`;

  // Description з локальними ключами
  const description = city
    ? `${t.services[page].desc} у ${cityName}. ✓ Безкоштовний замір. ✓ Гарантія 10 років. ☎ ${city.phone}`
    : `${t.services[page].desc}. ✓ Безкоштовний замір по всій Україні.`;

  // Canonical URL
  const canonical = buildCanonicalUrl({ page, city, locale, slug });

  // hreflang alternates
  const languages = buildHreflangAlternates({ page, city, slug });

  return {
    title,
    description,
    alternates: { canonical, languages },
    openGraph: {
      title,
      description,
      url: canonical,
      siteName: "NOVA STELYA",
      locale: locale === "uk" ? "uk_UA" : "ru_UA",
      type: "website",
      images: [{ url: `/og/${page}${city ? `-${city.slug}` : ""}.jpg`, width: 1200, height: 630 }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: { index: true, follow: true, "max-image-preview": "large" },
    },
    ...overrides,
  };
}

// Приклад використання в page.tsx:
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const city = getCityBySlug(params.city);
  return generatePageMetadata({
    page: "matte-ceilings",
    city: city ?? undefined,
    locale: params.locale as "uk" | "ru",
  });
}
```

### hreflang для кожної сторінки

```typescript
// Обов'язково для КОЖНОЇ сторінки:
// uk (без префікса) ↔ ru (/ru/) ↔ x-default (uk)

function buildHreflangAlternates({ page, city, slug }) {
  const base = "https://novastelya.com";
  const path = buildPath({ page, city, slug });

  return {
    "x-default": `${base}${path}`,           // uk версія як дефолт
    "uk": `${base}${path}`,
    "ru": `${base}/ru${path}`,
  };
}
```

-----

## 7. SEO: SCHEMA.ORG JSON-LD

### Обов’язкові Schema для кожного типу сторінки:

#### Головна сторінка:

```typescript
// Organization + WebSite + LocalBusiness
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://novastelya.com/#organization",
      "name": "NOVA STELYA",
      "url": "https://novastelya.com",
      "logo": { "@type": "ImageObject", "url": "https://novastelya.com/logo.png" },
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+380-800-000-000",
        "contactType": "customer service",
        "availableLanguage": ["Ukrainian", "Russian"]
      }
    },
    {
      "@type": "WebSite",
      "@id": "https://novastelya.com/#website",
      "url": "https://novastelya.com",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://novastelya.com/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }
  ]
}
```

#### Сторінка послуги в місті:

```typescript
// HomeAndConstructionBusiness + Service + BreadcrumbList + FAQPage
{
  "@type": "HomeAndConstructionBusiness",
  "@id": `https://novastelya.com/${city.slug}/#business`,
  "name": `NOVA STELYA ${city.uk}`,
  "image": `https://novastelya.com/og/office-${city.slug}.jpg`,
  "telephone": city.phone,
  "address": {
    "@type": "PostalAddress",
    "streetAddress": city.address,
    "addressLocality": city.uk,
    "addressRegion": city.region,
    "addressCountry": "UA"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": city.coordinates.lat,
    "longitude": city.coordinates.lon
  },
  "openingHoursSpecification": { /* ... */ },
  "areaServed": {
    "@type": "City",
    "name": city.uk,
    // GEO/AEO: прив'язка до конкретних ЖК
    "containsPlace": city.landmarks.map(lm => ({
      "@type": "Residence",
      "name": lm
    }))
  },
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Натяжні стелі",
    "itemListElement": [{
      "@type": "Offer",
      "itemOffered": {
        "@type": "Service",
        "name": `Матові натяжні стелі у ${city.uk}`,
        "description": "...",
      },
      "price": Math.round(basePrice * city.priceModifier),
      "priceCurrency": "UAH"
    }]
  }
}
```

#### Обов’язкові Schema per тип:

|Тип сторінки   |Schema                                                |
|---------------|------------------------------------------------------|
|Головна        |Organization + WebSite + LocalBusiness                |
|Послуга        |Service + HomeAndConstructionBusiness + BreadcrumbList|
|Послуга в місті|Service + LocalBusiness + BreadcrumbList + FAQPage    |
|FAQ            |FAQPage                                               |
|Blog/Стаття    |Article + BreadcrumbList + Person (author)            |
|Портфоліо      |ImageGallery + BreadcrumbList                         |
|Прайс          |Product + Offer + Table                               |
|Місто-хаб      |LocalBusiness + BreadcrumbList + ItemList (послуги)   |

-----

## 8. SEO: SITEMAP & ROBOTS

### app/sitemap.ts — повна автогенерація

```typescript
import { MetadataRoute } from "next";
import { activeCities } from "@/config/geo-matrix";
import { services } from "@/config/services.config";
import { getBlogSlugs, getPortfolioSlugs } from "@/lib/sanity";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://novastelya.com";
  const locales = ["", "/ru"] as const;
  const now = new Date();

  const urls: MetadataRoute.Sitemap = [];

  // 1. Статичні сторінки
  const staticPages = ["/", "/prices", "/faq", "/portfolio", "/blog", "/contacts"];
  for (const locale of locales) {
    for (const page of staticPages) {
      urls.push({
        url: `${base}${locale}${page}`,
        lastModified: now,
        changeFrequency: page === "/" ? "weekly" : "monthly",
        priority: page === "/" ? 1.0 : 0.8,
        alternates: {
          languages: {
            "uk": `${base}${page}`,
            "ru": `${base}/ru${page}`,
          }
        }
      });
    }
  }

  // 2. Послуги (без міст)
  for (const locale of locales) {
    for (const service of services) {
      urls.push({
        url: `${base}${locale}/${service.slug}/`,
        lastModified: now,
        changeFrequency: "monthly",
        priority: 0.9,
      });
    }
  }

  // 3. Міста-хаби
  for (const locale of locales) {
    for (const city of activeCities) {
      urls.push({
        url: `${base}${locale}/${city.slug}/`,
        lastModified: now,
        changeFrequency: "weekly",
        priority: 0.85,
      });
    }
  }

  // 4. Місто × Послуга (ключові SEO сторінки)
  for (const locale of locales) {
    for (const city of activeCities) {
      for (const service of services) {
        urls.push({
          url: `${base}${locale}/${city.slug}/${service.slug}/`,
          lastModified: now,
          changeFrequency: "monthly",
          priority: 0.8,
        });
      }
    }
  }

  // 5. Блог
  const blogSlugs = await getBlogSlugs();
  for (const locale of locales) {
    for (const slug of blogSlugs) {
      urls.push({
        url: `${base}${locale}/blog/${slug}/`,
        lastModified: now,
        changeFrequency: "weekly",
        priority: 0.7,
      });
    }
  }

  return urls;
}
```

### app/robots.ts

```typescript
import { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = "https://novastelya.com";
  const isProd = process.env.NODE_ENV === "production";

  return {
    rules: isProd
      ? [
          {
            userAgent: "*",
            allow: "/",
            disallow: ["/api/", "/_next/", "/admin/"],
          },
          // Дозволяємо AI-краулерам повний доступ (GEO/AEO)
          {
            userAgent: ["GPTBot", "ClaudeBot", "PerplexityBot", "Googlebot"],
            allow: "/",
          },
        ]
      : [{ userAgent: "*", disallow: "/" }],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}
```

-----

## 9. I18N: МУЛЬТИМОВНІСТЬ

### Конфігурація (next-intl)

```typescript
// i18n.config.ts
export const locales = ["uk", "ru"] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = "uk";
```

### middleware.ts

```typescript
import createMiddleware from "next-intl/middleware";
import { NextRequest, NextResponse } from "next/server";
import { locales, defaultLocale } from "./i18n.config";

const intlMiddleware = createMiddleware({
  locales,
  defaultLocale,
  localePrefix: "as-needed",  // uk = /, ru = /ru
});

const AI_BOTS = [
  "Googlebot", "GPTBot", "ClaudeBot", "PerplexityBot",
  "anthropic-ai", "cohere-ai", "Applebot"
];

export async function middleware(request: NextRequest) {
  const ua = request.headers.get("user-agent") ?? "";
  const isBot = AI_BOTS.some(bot => ua.includes(bot));
  const isGooglebot = ua.includes("Googlebot");

  // Bot Detection — AI-краулери отримують чистий SSR
  if (isBot) {
    const response = await intlMiddleware(request);
    response.headers.set("x-render-mode", "static");
    response.headers.set("x-is-bot", "true");
    return response;
  }

  // City Detection для живих користувачів
  const preferredCity = request.cookies.get("preferred-city")?.value;
  const detectedCity = request.geo?.city?.toLowerCase();   // Vercel Edge geo

  const response = await intlMiddleware(request);

  if (!preferredCity && detectedCity) {
    response.headers.set("x-detected-city", detectedCity);
  }

  return response;
}

export const config = {
  matcher: ["/((?!api|_next|_vercel|.*\\..*).*)"],
};
```

### Структура перекладів

```json
// messages/uk.json (приклад структури)
{
  "nav": { "home": "Головна", "catalog": "Каталог", ... },
  "services": {
    "matte-ceilings": {
      "title": "Матові натяжні стелі",
      "desc": "Елегантні матові стелі без відблисків...",
      "h1": "Матові натяжні стелі — ціна за м²",
      "breadcrumb": "Матові"
    }
  },
  "cities": {
    "kyiv": { "inCity": "у Києві", "fromCity": "з Києва" },
    "dnipro": { "inCity": "у Дніпрі", "fromCity": "з Дніпра" }
  },
  "seo": {
    "titleTemplate": "%s | NOVA STELYA",
    "defaultTitle": "Натяжні стелі — NOVA STELYA"
  }
}
```

-----

## 10. СИСТЕМА МІСТ (CITY-IN-A-BOX)

### Як додати нове місто

**Крок 1** — додати об’єкт в `geo-matrix.ts`:

```typescript
{
  slug: "lviv",
  uk: "Львів",
  ru: "Львов",
  region: "UA-46",
  active: true,          // ← просто змінити з false на true
  phone: "+380 32 000-00-00",
  address: "пл. Ринок, 1, Львів",
  addressRu: "пл. Рынок, 1, Львов",
  coordinates: { lat: 49.8397, lon: 24.0297 },
  priceModifier: 0.95,
  landmarks: ["ЖК Пасічний", "ЖК Синергія Сіті"],
  officeHours: "Пн-Сб 9:00-19:00",
}
```

**Крок 2** — додати переклади в `messages/uk.json`:

```json
"cities": { "lviv": { "inCity": "у Львові", "fromCity": "зі Львова" } }
```

**Результат — автоматично генерується:**

- `/lviv` — хаб міста
- `/lviv/matte-ceilings` — і всі інші послуги
- `/lviv/prices`, `/lviv/portfolio`, `/lviv/faq`
- `/ru/lviv` та всі ru-підсторінки
- Всі записи в sitemap.xml
- LocalBusiness Schema з координатами
- hreflang alternates
- Регіональні ціни (basePrice × priceModifier)
- Унікальні title/description/canonical

### generateStaticParams для міст

```typescript
// app/[locale]/[city]/page.tsx
export function generateStaticParams() {
  const locales = ["uk", "ru"];
  return locales.flatMap(locale =>
    activeCities.map(city => ({ locale, city: city.slug }))
  );
}

// app/[locale]/[city]/[service]/page.tsx
export function generateStaticParams() {
  const locales = ["uk", "ru"];
  return locales.flatMap(locale =>
    activeCities.flatMap(city =>
      services.map(service => ({
        locale,
        city: city.slug,
        service: service.slug
      }))
    )
  );
}
```

### Smart City Banner (Server Component)

```typescript
// Server Component — без localStorage, без CLS, без FOUC
import { headers } from "next/headers";
import { CityBannerClient } from "./CityBannerClient";

async function CityBanner() {
  const headersList = headers();
  const detectedCity = headersList.get("x-detected-city");

  if (!detectedCity) return null;

  const cityConfig = getCityBySlug(detectedCity);
  if (!cityConfig) return null;

  return <CityBannerClient city={cityConfig} />;
}

// CityBannerClient — тільки dismiss логіка
"use client";
export function CityBannerClient({ city }) {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;

  return (
    <div role="banner" aria-label="Визначення міста">
      Ваше місто {city.uk}?{" "}
      <a href={`/${city.slug}/`}>Перейти на локальну сторінку</a>
      <button onClick={() => {
        setDismissed(true);
        document.cookie = `preferred-city=${city.slug}; max-age=2592000; path=/`;
      }}>
        Так, це мій місто
      </button>
    </div>
  );
}
```

-----

## 11. MIDDLEWARE: EDGE ROUTING

```
Запит → middleware.ts (Edge, ~0ms)
  ├── Bot? → SSR mode header → intlMiddleware
  ├── Cookie "preferred-city"? → без редиректу, просто header
  ├── Vercel geo header? → x-detected-city header
  └── intlMiddleware → uk=/ або ru=/ru
```

-----

## 12. КОМПОНЕНТИ ТА БЛОКИ СТОРІНОК

### LEGO-архітектура: page-blocks.config.ts

```typescript
// src/config/page-blocks.config.ts
export const pageBlocks = {
  "matte-ceilings": [
    "HeroService",        // H1 + фото + CTA
    "ServiceBenefits",    // Переваги матових стель
    "Gallery",            // Фотогалерея з Sanity
    "PriceTable",         // Таблиця цін (регіональна якщо є city)
    "Calculator",         // Розрахунок вартості
    "ServiceProcess",     // Як відбувається монтаж
    "Reviews",            // Відгуки клієнтів
    "FAQSection",         // FAQPage Schema
    "CTA",                // Заклик до дії
  ],
  "double-level-ceilings": [
    "HeroService",
    "3DShowcase",         // 3D-візуалізація дворівневих стель
    "Gallery",
    "PriceTable",
    "Calculator",
    "ServiceProcess",
    "Reviews",
    "FAQSection",
    "CTA",
  ],
  // city-hub сторінки
  "city-hub": [
    "HeroCityHub",        // H1 з назвою міста + local фото
    "CityServices",       // Сітка всіх послуг з цінами
    "LocalAdvantages",    // Переваги для конкретного міста
    "LocalPortfolio",     // Роботи в цьому місті
    "LocalReviews",       // Відгуки з цього міста
    "Map",                // Google Maps з офісом
    "CTA",
  ],
} as const;
```

### Обов’язкові вимоги до компонентів:

```
✅ Всі зображення: next/image з обов'язковими width, height, alt
✅ alt тексти: включають назву послуги + місто (для Gemini multimodal)
✅ Lazy loading: тільки above-the-fold = priority, решта = lazy
✅ React Server Components за замовчуванням
✅ "use client" тільки для інтерактивних елементів
✅ Шрифти: тільки next/font (zero layout shift)
✅ Іконки: SVG inline або @phosphor-icons/react (tree-shakeable)
✅ Анімації: CSS тільки (без Framer Motion на критичному шляху)
```

-----

## 13. КАЛЬКУЛЯТОР І ФОРМИ

### Калькулятор (React Client Component)

```typescript
"use client";
// Чистий React без сторонніх бібліотек
// useState + useEffect + useCallback

type CalculatorState = {
  area: number;
  ceilingType: ServiceSlug;
  city: CitySlug | null;
  hasLighting: boolean;
};

// Валідація телефону
const PHONE_MASK = "+38 (0__) ___-__-__";
const phoneRegex = /^\+38\s\(0\d{2}\)\s\d{3}-\d{2}-\d{2}$/;
```

### API Route для форм

```typescript
// app/api/contact/route.ts
// Токени бота НІКОЛИ не потрапляють у браузер

export async function POST(request: Request) {
  const body = await request.json();

  // Серверна валідація (Zod)
  const result = ContactSchema.safeParse(body);
  if (!result.success) return Response.json({ error: "Invalid data" }, { status: 400 });

  const { name, phone, city, service, area } = result.data;

  // Telegram
  await sendTelegramMessage({
    token: process.env.TELEGRAM_BOT_TOKEN!,   // Серверна змінна
    chatId: process.env.TELEGRAM_CHAT_ID!,
    text: `Нова заявка:\n👤 ${name}\n📞 ${phone}\n📍 ${city}\n🏠 ${service} • ${area}м²`,
  });

  // Збереження в PostgreSQL
  await db.lead.create({ data: result.data });

  return Response.json({ success: true });
}
```

-----

## 14. PERFORMANCE: CORE WEB VITALS

### Цільові показники:

```
LCP:          < 1.2s     (mobile + desktop)
INP:          < 50ms
CLS:          0.00
TTFB:         < 50ms     (Edge CDN)
FCP:          < 0.8s
Lighthouse:   98-100     (mobile + desktop)
```

### next.config.ts:

```typescript
const config: NextConfig = {
  trailingSlash: false,                    // ОБОВ'ЯЗКОВО
  poweredByHeader: false,
  compress: true,
  images: {
    formats: ["image/avif", "image/webp"],
    deviceSizes: [640, 750, 828, 1080, 1200],
    minimumCacheTTL: 31536000,
    remotePatterns: [
      { protocol: "https", hostname: "cdn.sanity.io" },
      { protocol: "https", hostname: "res.cloudinary.com" },
    ],
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          // Preconnect для Cloudinary та Sanity
          { key: "Link", value: "<https://res.cloudinary.com>; rel=preconnect" },
        ],
      },
      {
        // Статичні ресурси: кеш на 1 рік
        source: "/_next/static/(.*)",
        headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }],
      },
    ];
  },
  async redirects() {
    return [
      // Редирект зі старих URL якщо є
      { source: "/ua/:path*", destination: "/:path*", permanent: true },
    ];
  },
};
```

### HTML / Semantic Rules

Использовать только максимально семантический HTML5.
* Использовать:
    * <main>
    * <header>
    * <footer>
    * <nav>
    * <section>
    * <article>
    * <aside>
    * <address>
    * <figure>
    * <figcaption>
    * <time>
    * <details>
    * <summary>
* Никогда не использовать div если можно использовать систематический тег

Accessibility (WCAG AA minimum)
Проект должен соответствовать:
WCAG 2.2 AA

Обязательные правила

### CSS стратегія — Zero Unused CSS:

```
✅ CSS Standards (Vanilla CSS only) Только: Modern Vanilla CSS(автоматичне видалення невикористаних класів)
Использовать современные возможности CSS
@layer
@scope
:has()
:is()
:where()
container queries
clamp()
min()
max()
logical properties
nesting
subgrid
Spacing system
Только scale:
--space-2xs
--space-xs
--space-sm
--space-md
--space-lg
--space-xl
никаких:
padding: 17px;
margin: 29px;
Запрещено: !important , глубокая вложенность: .card .box .item .text span

✅Naming
Только: 
component-name
component-name__element
is-active
has-error

✅ CSS Modules для компонент-специфічних стилів
✅ Critical CSS inline в <head> (тільки above-the-fold)
✅ Решта CSS — lazy load
❌ Ніяких глобальних CSS файлів крім мінімального reset
❌ Ніяких @import у CSS (тільки next/font)
```

-----

## 15. GEO/AEO: ОПТИМІЗАЦІЯ ДЛЯ AI

### Що таке GEO/AEO в 2026:

Google Gemini, ChatGPT, Claude, Perplexity — вибирають сайти як **джерела** для AI-відповідей. Щоб потрапити в цей список:

### Вимоги:

**1. Information Gain (Унікальність контенту)**

```
Кожна сторінка Місто × Послуга ПОВИННА містити:
- Реальні ціни з прив'язкою до міста
- Фото робіт в конкретних ЖК міста
- Місцеві технічні нюанси (висота стель, кліматичні особливості)
- Відгуки з іменами та адресами (ЖК/район)
- Приклади: "натяжна стеля в ЖК Файна Таун, Київ — 340 грн/м²"
```

**2. E-E-A-T сигнали:**

```
- Сторінка "Про компанію" з реальними фото команди
- Сертифікати виробників (Pongs, Descor, Lackmann) з Schema
- Портфоліо з датами та адресами об'єктів
- Автори статей в блозі з Person Schema
- Офіційні партнерства з Schema
```

**3. Структурований контент для AI-парсингу:**

```typescript
// alt тексти з повним контекстом:
alt="Матова натяжна стеля біла 40 м² у вітальні ЖК Комфорт Таун Київ — NOVA STELYA"

// Заголовки з семантичним змістом:
<h1>Матові натяжні стелі у Києві — ціна від 280 грн/м²</h1>
<h2>Скільки коштує матова натяжна стеля в Києві у 2026 році?</h2>
<h3>Матова стеля у ванній кімнаті — особливості монтажу</h3>
```

**4. FAQ на кожній сторінці (FAQPage Schema):**

```
Питання формулювати як реальні пошукові запити:
- "Скільки коштує матова натяжна стеля у Києві?"
- "Яка різниця між матовою та сатиновою стелею?"
- "Скільки часу займає монтаж натяжної стелі?"
```

-----

## 16. API ROUTES

```
POST /api/contact/          Заявка з форми / калькулятора
POST /api/revalidate/       Webhook від Sanity CMS → ISR revalidation
GET  /api/geo/              Визначення міста по IP (Edge Function)
```

### Захист API:

```typescript
// Захист від спаму
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(5, "10 m"), // 5 заявок / 10 хвилин з одного IP
});
```

-----

## 17. КРИТЕРІЇ ПРИЙОМУ (ACCEPTANCE CRITERIA)

### Обов’язково до здачі:

**Performance:**

- [ ] Lighthouse Mobile: Performance ≥ 98
- [ ] LCP < 1.2s на мобільному (Chrome DevTools throttled)
- [ ] INP < 50ms
- [ ] CLS = 0.00
- [ ] TTFB < 100ms (Vercel Edge)

**SEO Технічне:**

- [ ] trailingSlash: false Все slash-версии должны делать 301 redirect на canonical URL без `/`.
- [ ] Canonical URL на КОЖНІЙ сторінці
- [ ] hreflang uk ↔ ru ↔ x-default на КОЖНІЙ сторінці
- [ ] sitemap.xml покриває 100% активних URL
- [ ] robots.txt дозволяє індексацію + блокує /api/
- [ ] Немає дублікатів title/description
- [ ] Всі зображення мають alt тексти

**Schema.org:**

- [ ] JSON-LD на КОЖНІЙ сторінці (відповідний тип)
- [ ] LocalBusiness Schema для кожного міста
- [ ] FAQPage Schema на FAQ сторінках
- [ ] BreadcrumbList на всіх сторінках

**Функціональність:**

- [ ] Форма заявки → Telegram працює
- [ ] on-demand ISR revalidation від Sanity працює
- [ ] Smart City Banner показується при новому відвідуванні
- [ ] Cookie зберігає вибране місто

**Мультимовність:**

- [ ] /uk/ сторінки без префікса
- [ ] /ru/ сторінки з префіксом /ru/
- [ ] Перемикач мови на кожній сторінці
- [ ] Всі тексти через next-intl (нема хардкоду)

**City System:**

- [ ] Додавання міста = 1 об’єкт в geo-matrix.ts
- [ ] Нове місто отримує ВСІ сторінки автоматично
- [ ] Регіональні ціни розраховуються через priceModifier

-----

## 18. ЩО НЕ РОБИТИ

```
❌ НЕ використовувати pages/ router
❌ НЕ використовувати getServerSideProps / getStaticProps
❌ НЕ зберігати місто в localStorage (тільки cookie)
❌ НЕ використовувати catch-all [...slug] як основний роутинг
❌ НЕ хардкодити тексти — тільки next-intl
❌ НЕ підключати jQuery або будь-які CSS фреймворки
❌ НЕ додавати "use client" без потреби (RSC за замовчуванням)
❌ НЕ використовувати зображення без width/height/alt
❌ НЕ створювати окремі файли для кожної послуги-в-місті
   (генерувати через generateStaticParams)
❌ НЕ використовувати Framer Motion на критичному шляху рендерингу
```

-----

## ПІДСУМОК

Дана архітектура забезпечує:

**1 об’єкт в geo-matrix.ts** → нове місто з:

- Всіма сторінками послуг
- Правильними canonical та hreflang
- LocalBusiness Schema з координатами
- Регіональними цінами
- Записами в sitemap
- Smart City Banner

Це **золотий стандарт 2026** для мультирегіонального бізнес-сайту на Next.js.

-----

*NOVA STELYA Technical Specification v3.0 FINAL*  
*Next.js 15+ · App Router · Edge-First · Maximum SEO*