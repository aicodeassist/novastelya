# SEO PLATFORM LAYER — NOVA STELYA

## Специфікація v2.0 FINAL · Next.js 16.2+

> **Для AI-агента:** Це самостійний модуль `src/seo/`.
> Читай цей файл повністю перед будь-яким кодом.
> Головний принцип: **жодного SEO-коду поза `src/seo/`**.

-----

## ЗМІСТ

1. [Аудит пропозиції — що залишаємо, що змінюємо](#1-аудит)
1. [Фінальна архітектура](#2-фінальна-архітектура)
1. [Детальна специфікація кожного модуля](#3-специфікація-модулів)
1. [Public API — index.ts](#4-public-api)
1. [Правила використання в app/](#5-правила-використання)
1. [Типи TypeScript](#6-типи)
1. [Константи](#7-константи)
1. [Чеклист якості](#8-чеклист)

-----

## 1. АУДИТ

### Що в твоїй пропозиції — правильно ✅

|Рішення                              |Чому правильно                    |
|-------------------------------------|----------------------------------|
|`seo/` як окремий Platform Layer     |Єдина точка відповідальності      |
|`metadata/templates/` per page-type  |Кожен тип сторінки — свій шаблон  |
|`schema/builders/`                   |Фабрики незалежні, легко тестувати|
|`sitemap/routes/` розділений по типах|Масштабується без переписування   |
|`alternates/` як окремий модуль      |hreflang — критична SEO-логіка    |
|`urls/` як окремий модуль            |URL — фундамент всього SEO        |
|`types/`                             |TypeScript строгість обов’язкова  |
|`content/` з правилами               |SEO-копірайтинг system-driven     |

### Що змінюємо та чому ⚠️

|Пропозиція                                                                        |Проблема                           |Рішення                             |
|----------------------------------------------------------------------------------|-----------------------------------|------------------------------------|
|`builders/build-title.ts` окремий файл                                            |10 рядків не заслуговують файлу    |Частина `metadata/core.ts`          |
|`builders/build-twitter.ts`                                                       |3 рядки об’єкту                    |Частина `metadata/core.ts`          |
|`content/faq/` — директорія без файлів                                            |Незакінчена думка                  |`content/faq-rules.ts`              |
|`performance/` в seo/                                                             |Performance ≠ SEO layer            |Залишається в `src/lib/performance/`|
|`utils/slugify.ts`                                                                |Загальна утиліта, не SEO-специфічна|`src/lib/utils/`                    |
|`geo/service-area.ts` окремо                                                      |Частина `geo/local-seo.ts`         |Злити                               |
|`sitemap/change-frequency.ts` окремо                                              |10 рядків                          |Частина `sitemap/config.ts`         |
|Дублювання: `metadata/builders/build-hreflang.ts` + `alternates/build-hreflang.ts`|Дублювання логіки                  |Тільки в `alternates/`              |

### Що додаємо ➕

|Новий модуль            |Причина                                  |
|------------------------|-----------------------------------------|
|`schema/page-schemas.ts`|Комбінує builders для конкретних сторінок|
|`content/city-copy.ts`  |City-aware H1/CTA/descriptions           |
|`audit/`                |Runtime SEO audit в dev mode             |

-----

## 2. ФІНАЛЬНА АРХІТЕКТУРА

```
src/
└── seo/
    │
    ├── index.ts                        ← PUBLIC API (тільки звідси імпортувати)
    │
    ├── types/                          ← TypeScript першим
    │   ├── metadata.types.ts
    │   ├── schema.types.ts
    │   ├── seo.types.ts
    │   └── index.ts
    │
    ├── constants/                      ← незмінні значення
    │   ├── site.ts                     ← SITE_URL, SITE_NAME, BRAND
    │   ├── locales.ts                  ← локалі, x-default логіка
    │   ├── seo-defaults.ts             ← fallback title/desc/OG
    │   ├── routes.ts                   ← всі slug константи
    │   └── index.ts
    │
    ├── urls/                           ← фундамент: побудова URL
    │   ├── build-path.ts               ← buildPath(page, city?, locale)
    │   ├── build-canonical.ts          ← buildCanonicalUrl(...)
    │   ├── route-map.ts                ← повна карта роутів
    │   ├── redirects.ts                ← 301 правила
    │   └── index.ts
    │
    ├── alternates/                     ← hreflang — окрема відповідальність
    │   ├── build-hreflang.ts           ← buildHreflangAlternates(...)
    │   ├── locales-map.ts              ← uk→uk_UA, ru→ru_UA маппінг
    │   └── index.ts
    │
    ├── metadata/                       ← Metadata API
    │   ├── core.ts                     ← buildTitle, buildDescription,
    │   │                                  buildOG, buildTwitter (разом)
    │   ├── generate-page-metadata.ts   ← головна функція
    │   ├── templates/                  ← шаблон per тип сторінки
    │   │   ├── home.ts
    │   │   ├── service.ts
    │   │   ├── city.ts
    │   │   ├── city-service.ts         ← НОВИЙ: місто × послуга (ключовий)
    │   │   ├── prices.ts
    │   │   ├── faq.ts
    │   │   ├── blog-list.ts
    │   │   ├── blog-post.ts
    │   │   ├── portfolio.ts
    │   │   └── contacts.ts
    │   └── index.ts
    │
    ├── schema/                         ← Schema.org JSON-LD
    │   ├── builders/                   ← атомарні фабрики
    │   │   ├── organization.ts
    │   │   ├── local-business.ts
    │   │   ├── service.ts
    │   │   ├── faq.ts
    │   │   ├── breadcrumb.ts
    │   │   ├── article.ts
    │   │   ├── review.ts
    │   │   ├── aggregate-rating.ts
    │   │   └── image-gallery.ts        ← НОВИЙ: для портфоліо
    │   ├── page-schemas.ts             ← НОВИЙ: комбінує builders per тип
    │   ├── inject/
    │   │   └── jsonld.tsx              ← <JsonLd schema={...} />
    │   └── index.ts
    │
    ├── sitemap/                        ← повна автогенерація
    │   ├── config.ts                   ← priorities + changeFrequency разом
    │   ├── routes/
    │   │   ├── static-routes.ts
    │   │   ├── service-routes.ts
    │   │   ├── city-routes.ts
    │   │   ├── city-service-routes.ts  ← НОВИЙ: матриця місто × послуга
    │   │   ├── blog-routes.ts
    │   │   └── portfolio-routes.ts
    │   ├── generate-sitemap.ts         ← збирає всі routes
    │   └── index.ts
    │
    ├── robots/
    │   ├── generate-robots.ts
    │   └── index.ts
    │
    ├── geo/                            ← Local SEO
    │   ├── local-seo.ts                ← service-area + LocalBusiness логіка
    │   ├── geo-tags.ts                 ← <GeoMetaTags /> компонент
    │   └── index.ts
    │
    ├── content/                        ← SEO-контент system-driven
    │   ├── city-copy.ts                ← city-aware H1, CTA, descriptions
    │   ├── faq-rules.ts                ← універсальні FAQ (без city-спаму)
    │   ├── seo-copy-rules.ts           ← правила написання SEO-текстів
    │   ├── title-rules.ts              ← довжина, шаблони, заборони
    │   ├── description-rules.ts        ← довжина, ключові слова
    │   ├── forbidden-patterns.ts       ← що НІКОЛИ не писати
    │   └── index.ts
    │
    └── audit/                          ← dev-only SEO audit
        ├── validate-metadata.ts        ← перевірка title/desc довжини
        ├── validate-schema.ts          ← перевірка JSON-LD структури
        └── index.ts
```

-----

## 3. СПЕЦИФІКАЦІЯ МОДУЛІВ

### 3.1 `types/` — типи першими

```typescript
// types/seo.types.ts
import type { CityConfig } from "@/config/geo-matrix";

export type Locale = "uk" | "ru";
export type ServiceSlug = "matte-ceilings" | "glossy-ceilings" | "satin-ceilings"
  | "fabric-ceilings" | "shadow-ceilings" | "floating-ceilings"
  | "slotted-ceilings" | "carved-ceilings" | "double-level-ceilings"
  | "light-lines" | "track-lighting" | "backlight" | "starry-sky"
  | "kitchen-ceilings" | "bathroom-ceilings" | "bedroom-ceilings"
  | "living-room-ceilings";

export type PageType =
  | "home"
  | "service"
  | "city"
  | "city-service"      // ← ключова комбінація
  | "prices"
  | "faq"
  | "blog-list"
  | "blog-post"
  | "portfolio"
  | "contacts";

export type SeoContext = {
  pageType: PageType;
  locale: Locale;
  city?: CityConfig;
  serviceSlug?: ServiceSlug;
  blogSlug?: string;
  portfolioSlug?: string;
  basePrice?: number;
};
```

```typescript
// types/metadata.types.ts
export type TitleConfig = {
  pattern: string;         // "{service} у {city} — {brand}"
  maxLength: 60;
  minLength: 30;
};

export type DescriptionConfig = {
  pattern: string;
  maxLength: 155;
  minLength: 100;
  mustInclude: string[];   // обов'язкові слова
};
```

```typescript
// types/schema.types.ts
import type { Thing, WithContext } from "schema-dts";

export type SchemaGraph = {
  "@context": "https://schema.org";
  "@graph": Thing[];
};

export type PageSchemaConfig = {
  pageType: PageType;
  city?: CityConfig;
  service?: ServiceConfig;
  faqItems?: FAQItem[];
  breadcrumbs?: BreadcrumbItem[];
};
```

-----

### 3.2 `constants/` — незмінні значення

```typescript
// constants/site.ts
export const SITE = {
  url: "https://novastelya.com",
  name: "NOVA STELYA",
  brand: "NOVA STELYA",
  defaultLocale: "uk",
  phone0800: "0 800 000-000",
  email: "info@novastelya.com",
  foundingYear: 2015,
} as const;
```

```typescript
// constants/locales.ts
export const LOCALES = {
  uk: {
    code: "uk",
    hreflang: "uk-UA",       // ✅ для <link rel="alternate">
    prefix: "",
    ogLocale: "uk_UA",       // для OpenGraph
    label: "Українська",
  },
  ru: {
    code: "ru",
    hreflang: "ru-UA",       // ✅ ru-UA не ru-RU (бізнес в Україні!)
    prefix: "/ru",
    ogLocale: "ru_UA",
    label: "Русский",
  },
} as const;

export const DEFAULT_LOCALE = "uk" as const;
// x-default завжди вказує на uk-UA версію
export const XDEFAULT_LOCALE = "uk" as const;
```

```typescript
// constants/seo-defaults.ts
// Fallback значення коли немає специфічних даних
export const SEO_DEFAULTS = {
  titleSuffix: "| NOVA STELYA",
  titleTemplate: "{page} | NOVA STELYA",
  ogImage: "/og/default.jpg",         // 1200×630
  ogImageWidth: 1200,
  ogImageHeight: 630,
  twitterCard: "summary_large_image" as const,
  robots: "index, follow",
  googlebot: "index, follow, max-image-preview:large",
} as const;
```

```typescript
// constants/routes.ts
// Всі slug як константи — ніякого хардкоду в app/
export const ROUTES = {
  home: "/",
  prices: "/prices/",
  faq: "/faq/",
  portfolio: "/portfolio/",
  blog: "/blog/",
  contacts: "/contacts/",
  services: {
    "matte-ceilings": "/matte-ceilings/",
    "glossy-ceilings": "/glossy-ceilings/",
    // ... всі 18 послуг
  },
} as const;
```

-----

### 3.3 `urls/` — фундамент побудови URL

```typescript
// urls/build-path.ts
import { LOCALES } from "@/seo/constants";
import type { SeoContext } from "@/seo/types";

/**
 * Єдина функція побудови шляху.
 * Всі URL сайту проходять через неї.
 */
export function buildPath({
  pageType,
  locale,
  city,
  serviceSlug,
  blogSlug,
  portfolioSlug,
}: SeoContext): string {
  const pfx = LOCALES[locale].prefix;

  switch (pageType) {
    case "home":         return `${pfx}/`;
    case "service":      return `${pfx}/${serviceSlug}/`;
    case "city":         return `${pfx}/${city!.slug}/`;
    case "city-service": return `${pfx}/${city!.slug}/${serviceSlug}/`;
    case "prices":       return `${pfx}/prices/`;
    case "faq":          return `${pfx}/faq/`;
    case "blog-list":    return `${pfx}/blog/`;
    case "blog-post":    return `${pfx}/blog/${blogSlug}/`;
    case "portfolio":    return `${pfx}/portfolio/`;
    case "contacts":     return `${pfx}/contacts/`;
    default:             return `${pfx}/`;
  }
}
```

```typescript
// urls/build-canonical.ts
import { SITE } from "@/seo/constants";
import { buildPath } from "./build-path";
import type { SeoContext } from "@/seo/types";

export function buildCanonicalUrl(ctx: SeoContext): string {
  return `${SITE.url}${buildPath(ctx)}`;
}
```

```typescript
// urls/redirects.ts
// 301 правила — всі в одному місці
export const REDIRECTS = [
  // Без trailing slash → зі слешем (обробляється next.config.ts)
  // Старі URL якщо були
  { source: "/ua/:path*", destination: "/:path*", permanent: true },
  { source: "/index.html", destination: "/", permanent: true },
] as const;
```

-----

### 3.4 `alternates/` — hreflang

```typescript
// alternates/build-hreflang.ts
import { SITE, LOCALES } from "@/seo/constants";
import { buildPath } from "@/seo/urls";
import type { SeoContext } from "@/seo/types";

export type HreflangAlternates = {
  "x-default": string;
  "uk-UA": string;   // ✅ мова-РЕГІОН: Ukrainian + Ukraine
  "ru-UA": string;   // ✅ мова-РЕГІОН: Russian + Ukraine (НЕ ru-RU!)
};

// Генерує:
// <link rel="alternate" hreflang="uk-UA" href="...">
// <link rel="alternate" hreflang="ru-UA" href="...">
// <link rel="alternate" hreflang="x-default" href="...">
//
// ЧОМУ ru-UA а не ru-RU:
// Бізнес працює в Україні, контент для користувачів в Україні.
// ru-RU сигналізує Google що контент для Росії — SEO-катастрофа.

/**
 * Генерує hreflang для будь-якої сторінки.
 * x-default завжди = uk-UA версія.
 */
export function buildHreflangAlternates(
  ctx: Omit<SeoContext, "locale">
): HreflangAlternates {
  const ukPath = buildPath({ ...ctx, locale: "uk" });
  const ruPath = buildPath({ ...ctx, locale: "ru" });

  return {
    "x-default": `${SITE.url}${ukPath}`,
    "uk-UA":     `${SITE.url}${ukPath}`,
    "ru-UA":     `${SITE.url}${ruPath}`,
  };
}
```

-----

### 3.5 `metadata/` — Metadata API

```typescript
// metadata/core.ts
// Всі примітивні builders в одному файлі (вони малі)

import { SEO_DEFAULTS, SITE } from "@/seo/constants";
import type { SeoContext } from "@/seo/types";

export function buildTitle(title: string): string {
  // Обрізаємо до 60 символів, додаємо бренд
  const full = `${title} | ${SITE.name}`;
  return full.length > 60 ? title.substring(0, 57) + "..." : full;
}

export function buildDescription(desc: string): string {
  // Обрізаємо до 155 символів
  return desc.length > 155 ? desc.substring(0, 152) + "..." : desc;
}

export function buildOpenGraph({
  title, description, url, locale, imageSlug,
}: {
  title: string; description: string; url: string;
  locale: "uk" | "ru"; imageSlug?: string;
}) {
  return {
    title,
    description,
    url,
    siteName: SITE.name,
    locale: locale === "uk" ? "uk_UA" : "ru_UA",
    type: "website" as const,
    images: [{
      url: `${SITE.url}/og/${imageSlug ?? "default"}.jpg`,
      width: SEO_DEFAULTS.ogImageWidth,
      height: SEO_DEFAULTS.ogImageHeight,
      alt: title,
    }],
  };
}

export function buildTwitterCard(title: string, description: string) {
  return {
    card: SEO_DEFAULTS.twitterCard,
    title,
    description,
  };
}
```

```typescript
// metadata/generate-page-metadata.ts
import type { Metadata } from "next";
import type { SeoContext } from "@/seo/types";
import { buildCanonicalUrl } from "@/seo/urls";
import { buildHreflangAlternates } from "@/seo/alternates";
import { buildOpenGraph, buildTwitterCard } from "./core";
import { getMetadataTemplate } from "./templates";
import { SEO_DEFAULTS } from "@/seo/constants";

/**
 * ГОЛОВНА ФУНКЦІЯ SEO ПЛАТФОРМИ.
 * Єдина точка генерації Metadata для будь-якої сторінки.
 *
 * Використання в page.tsx:
 * export async function generateMetadata({ params }): Promise<Metadata> {
 *   return generatePageMetadata({
 *     pageType: "city-service",
 *     locale: params.locale,
 *     city: getCityBySlug(params.city),
 *     serviceSlug: params.service,
 *     basePrice: 280,
 *   });
 * }
 */
export function generatePageMetadata(ctx: SeoContext): Metadata {
  const template = getMetadataTemplate(ctx);
  const canonical = buildCanonicalUrl(ctx);
  const alternates = buildHreflangAlternates(ctx);

  return {
    title: template.title,
    description: template.description,
    alternates: {
      canonical,
      languages: alternates,
    },
    openGraph: buildOpenGraph({
      title: template.title,
      description: template.description,
      url: canonical,
      locale: ctx.locale,
      imageSlug: template.ogImageSlug,
    }),
    twitter: buildTwitterCard(template.title, template.description),
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
    ...template.overrides,
  };
}
```

```typescript
// metadata/templates/city-service.ts
// ← НАЙВАЖЛИВІШИЙ ШАБЛОН: місто × послуга

import { buildTitle, buildDescription } from "../core";
import type { SeoContext } from "@/seo/types";

export function getCityServiceMetadata(ctx: SeoContext) {
  const { city, serviceSlug, locale, basePrice = 280 } = ctx;
  const cityName = city![locale];
  const price = Math.round(basePrice * city!.priceModifier);
  const phone = city!.phone;

  // Відмінкові форми
  const inCity: Record<string, Record<string, string>> = {
    kyiv:    { uk: "у Києві",   ru: "в Киеве" },
    dnipro:  { uk: "у Дніпрі", ru: "в Днепре" },
    kharkiv: { uk: "у Харкові", ru: "в Харькове" },
  };
  const cityPhrase = inCity[city!.slug]?.[locale] ?? `у ${cityName}`;

  if (locale === "uk") {
    return {
      title: buildTitle(
        `Натяжні стелі ${cityPhrase} — від ${price} грн/м²`
      ),
      description: buildDescription(
        `Натяжні стелі ${cityPhrase}. ✓ Від ${price} грн/м². `
        + `✓ Безкоштовний замір. ✓ Гарантія 10 років. `
        + `Телефон: ${phone}.`
      ),
      ogImageSlug: `city-service-${city!.slug}`,
    };
  }

  return {
    title: buildTitle(
      `Натяжные потолки ${cityPhrase} — от ${price} грн/м²`
    ),
    description: buildDescription(
      `Натяжные потолки ${cityPhrase}. ✓ От ${price} грн/м². `
      + `✓ Бесплатный замер. ✓ Гарантия 10 лет. `
      + `Телефон: ${phone}.`
    ),
    ogImageSlug: `city-service-${city!.slug}`,
  };
}
```

```typescript
// metadata/templates/index.ts — роутер шаблонів

import type { SeoContext } from "@/seo/types";
import { getHomeMetadata }        from "./home";
import { getServiceMetadata }     from "./service";
import { getCityMetadata }        from "./city";
import { getCityServiceMetadata } from "./city-service";
import { getPricesMetadata }      from "./prices";
import { getFaqMetadata }         from "./faq";
import { getBlogListMetadata }    from "./blog-list";
import { getBlogPostMetadata }    from "./blog-post";
import { getPortfolioMetadata }   from "./portfolio";
import { getContactsMetadata }    from "./contacts";

export function getMetadataTemplate(ctx: SeoContext) {
  switch (ctx.pageType) {
    case "home":         return getHomeMetadata(ctx);
    case "service":      return getServiceMetadata(ctx);
    case "city":         return getCityMetadata(ctx);
    case "city-service": return getCityServiceMetadata(ctx);
    case "prices":       return getPricesMetadata(ctx);
    case "faq":          return getFaqMetadata(ctx);
    case "blog-list":    return getBlogListMetadata(ctx);
    case "blog-post":    return getBlogPostMetadata(ctx);
    case "portfolio":    return getPortfolioMetadata(ctx);
    case "contacts":     return getContactsMetadata(ctx);
  }
}
```

-----

### 3.6 `schema/` — Schema.org JSON-LD

```typescript
// schema/builders/local-business.ts

import { SITE } from "@/seo/constants";
import type { CityConfig } from "@/config/geo-matrix";

export function buildLocalBusiness(city: CityConfig, locale: "uk" | "ru") {
  const address = locale === "uk" ? city.address : city.addressRu;

  return {
    "@type": "HomeAndConstructionBusiness",
    "@id": `${SITE.url}/${city.slug}/#business`,
    "name": `${SITE.name} ${city[locale]}`,
    "url": `${SITE.url}/${city.slug}/`,
    "telephone": city.phone,
    "image": `${SITE.url}/og/office-${city.slug}.jpg`,
    "address": {
      "@type": "PostalAddress",
      "streetAddress": address,
      "addressLocality": city[locale],
      "addressRegion": city.region,
      "addressCountry": "UA",
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": city.coordinates.lat,
      "longitude": city.coordinates.lon,
    },
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
      "opens": "09:00",
      "closes": "20:00",
    },
    "areaServed": {
      "@type": "City",
      "name": city[locale],
      "containsPlace": city.landmarks.map(lm => ({
        "@type": "Residence",
        "name": lm,
      })),
    },
    "sameAs": city.sameAs ?? [],
  };
}
```

```typescript
// schema/page-schemas.ts
// Комбінує builders для конкретних типів сторінок

import { buildLocalBusiness } from "./builders/local-business";
import { buildService }       from "./builders/service";
import { buildBreadcrumb }    from "./builders/breadcrumb";
import { buildFaq }           from "./builders/faq";
import { buildOrganization }  from "./builders/organization";
import type { PageSchemaConfig } from "@/seo/types";

/**
 * Повертає масив Schema об'єктів для конкретного типу сторінки.
 * Використовується в JsonLd компоненті.
 */
export function getPageSchema(config: PageSchemaConfig): object[] {
  const { pageType, city, service, faqItems, breadcrumbs } = config;

  switch (pageType) {
    case "home":
      return [buildOrganization(), buildWebSite()];

    case "service":
      return [
        buildService(service!),
        buildBreadcrumb(breadcrumbs!),
        ...(faqItems ? [buildFaq(faqItems)] : []),
      ];

    case "city":
      return [
        buildLocalBusiness(city!, "uk"),
        buildBreadcrumb(breadcrumbs!),
        buildItemList(services),  // всі послуги міста
      ];

    case "city-service":
      return [
        buildLocalBusiness(city!, "uk"),
        buildService(service!, city),
        buildBreadcrumb(breadcrumbs!),
        ...(faqItems ? [buildFaq(faqItems)] : []),
      ];

    case "blog-post":
      return [buildArticle(config), buildBreadcrumb(breadcrumbs!)];

    case "portfolio":
      return [buildImageGallery(config), buildBreadcrumb(breadcrumbs!)];

    case "faq":
      return [buildFaq(faqItems!), buildBreadcrumb(breadcrumbs!)];

    default:
      return [buildOrganization()];
  }
}
```

```typescript
// schema/inject/jsonld.tsx
// Єдиний компонент для інжекції JSON-LD

type JsonLdProps = {
  schema: object | object[];
};

export function JsonLd({ schema }: JsonLdProps) {
  const graph = Array.isArray(schema) ? schema : [schema];

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": graph,
        }),
      }}
    />
  );
}

// Використання в page.tsx:
// <JsonLd schema={getPageSchema({ pageType: "city-service", city, service })} />
```

-----

### 3.7 `sitemap/` — повна автогенерація

```typescript
// sitemap/config.ts
// priorities та changeFrequency разом (вони пов'язані)

export const SITEMAP_CONFIG = {
  home:         { priority: 1.0, changeFrequency: "weekly" as const },
  service:      { priority: 0.9, changeFrequency: "monthly" as const },
  city:         { priority: 0.85, changeFrequency: "weekly" as const },
  "city-service":{ priority: 0.8, changeFrequency: "monthly" as const },
  prices:       { priority: 0.8, changeFrequency: "monthly" as const },
  faq:          { priority: 0.7, changeFrequency: "monthly" as const },
  "blog-list":  { priority: 0.75, changeFrequency: "weekly" as const },
  "blog-post":  { priority: 0.7, changeFrequency: "weekly" as const },
  portfolio:    { priority: 0.75, changeFrequency: "weekly" as const },
  contacts:     { priority: 0.6, changeFrequency: "yearly" as const },
} as const;
```

```typescript
// sitemap/routes/city-service-routes.ts
// ← НАЙВАЖЛИВІШИЙ файл: матриця місто × послуга

import { activeCities } from "@/config/geo-matrix";
import { services } from "@/config/services.config";
import { buildCanonicalUrl } from "@/seo/urls";
import { SITEMAP_CONFIG } from "../config";

export function getCityServiceRoutes() {
  const locales = ["uk", "ru"] as const;
  const config = SITEMAP_CONFIG["city-service"];

  return locales.flatMap(locale =>
    activeCities.flatMap(city =>
      services.map(service => ({
        url: buildCanonicalUrl({
          pageType: "city-service",
          locale,
          city,
          serviceSlug: service.slug,
        }),
        lastModified: new Date(),
        ...config,
        alternates: {
          languages: {
            "uk-UA": buildCanonicalUrl({ pageType: "city-service", locale: "uk", city, serviceSlug: service.slug }),
            "ru-UA": buildCanonicalUrl({ pageType: "city-service", locale: "ru", city, serviceSlug: service.slug }),
          }
        }
      }))
    )
  );
}
```

```typescript
// sitemap/generate-sitemap.ts
import type { MetadataRoute } from "next";
import { getStaticRoutes }      from "./routes/static-routes";
import { getServiceRoutes }     from "./routes/service-routes";
import { getCityRoutes }        from "./routes/city-routes";
import { getCityServiceRoutes } from "./routes/city-service-routes";
import { getBlogRoutes }        from "./routes/blog-routes";
import { getPortfolioRoutes }   from "./routes/portfolio-routes";

export async function generateSitemap(): Promise<MetadataRoute.Sitemap> {
  const [blogRoutes, portfolioRoutes] = await Promise.all([
    getBlogRoutes(),
    getPortfolioRoutes(),
  ]);

  return [
    ...getStaticRoutes(),
    ...getServiceRoutes(),
    ...getCityRoutes(),
    ...getCityServiceRoutes(),    // ← найбільший блок: N міст × M послуг × 2 локалі
    ...blogRoutes,
    ...portfolioRoutes,
  ];
}
```

-----

### 3.8 `geo/` — Local SEO

```typescript
// geo/geo-tags.ts
// Server Component — рендериться на сервері, нема CLS

import type { CityConfig } from "@/config/geo-matrix";

type GeoMetaTagsProps = {
  city: CityConfig;
};

export function GeoMetaTags({ city }: GeoMetaTagsProps) {
  return (
    <>
      <meta name="geo.region" content={city.region} />
      <meta name="geo.placename" content={city.uk} />
      <meta name="geo.position" content={`${city.coordinates.lat};${city.coordinates.lon}`} />
      <meta name="ICBM" content={`${city.coordinates.lat}, ${city.coordinates.lon}`} />
    </>
  );
}
```

```typescript
// geo/local-seo.ts
// Хелпери для Local SEO + service area

import type { CityConfig } from "@/config/geo-matrix";
import { activeCities } from "@/config/geo-matrix";

/**
 * Генерує service area для Schema.org
 * Включає місто + сусідні райони з geo-matrix
 */
export function buildServiceArea(city: CityConfig) {
  return [
    { "@type": "City", "name": city.uk },
    ...city.districts.map(d => ({ "@type": "AdministrativeArea", "name": d })),
    ...(city.nearbyCity ? [{ "@type": "City", "name": city.nearbyCity }] : []),
  ];
}

/**
 * Всі активні міста для Schema.org areaServed на головній
 */
export function buildNationalServiceArea() {
  return activeCities.map(city => ({
    "@type": "City",
    "name": city.uk,
    "addressRegion": city.region,
  }));
}
```

-----

### 3.9 `content/` — SEO-контент rules

```typescript
// content/faq-rules.ts
// Універсальні FAQ — БЕЗ city-спаму
// Місто вставляється тільки в ціну та телефон (одна строка)

import type { CityConfig } from "@/config/geo-matrix";
import type { Locale } from "@/seo/types";

export type FAQItem = { question: string; answer: string };

export function getServiceFAQ(
  serviceSlug: string,
  locale: Locale,
  city?: CityConfig,
  basePrice = 280,
): FAQItem[] {
  const price = city ? Math.round(basePrice * city.priceModifier) : basePrice;
  const phone = city?.phone ?? "0 800 000-000";

  // Запитання — загальні (не прив'язані до міста)
  // Місто входить тільки в одну фразу ціни/телефону
  if (locale === "uk") {
    return [
      {
        question: "Яка різниця між матовою та сатиновою натяжною стелею?",
        answer: "Матова стеля поглинає світло і приховує нерівності. Сатинова — має легкий блиск і візуально збільшує простір. Для спалень рекомендуємо матову, для вітальні — сатинову.",
      },
      {
        question: "Скільки коштує натяжна стеля?",
        answer: `Вартість залежить від типу плівки та площі. Ціна від ${price} грн/м². Точний розрахунок — безкоштовний замір: ${phone}.`,
      },
      {
        question: "Скільки часу займає монтаж натяжної стелі?",
        answer: "Стандартна кімната площею 20–30 м² монтується за 1–3 години. Двокімнатна квартира — за 1 день.",
      },
      {
        question: "Яка гарантія на натяжні стелі?",
        answer: "NOVA STELYA надає гарантію 10 років на плівку та монтаж. Використовуємо матеріали Pongs та Lackmann (Німеччина).",
      },
      {
        question: "Чи можна встановити натяжну стелю у ванній кімнаті?",
        answer: "Так. Для ванної використовується вологостійка ПВХ-плівка. Вона витримує до 100 л води при протіканні від сусідів.",
      },
    ];
  }

  // ru версія — аналогічна структура
  return [
    {
      question: "В чём разница между матовым и сатиновым натяжным потолком?",
      answer: "Матовый потолок поглощает свет и скрывает неровности. Сатиновый — имеет лёгкий блеск и визуально увеличивает пространство.",
    },
    {
      question: "Сколько стоит натяжной потолок?",
      answer: `Стоимость зависит от типа плёнки и площади. Цена от ${price} грн/м². Точный расчёт — бесплатный замер: ${phone}.`,
    },
    {
      question: "Сколько времени занимает монтаж натяжного потолка?",
      answer: "Стандартная комната 20–30 м² монтируется за 1–3 часа. Двухкомнатная квартира — за 1 день.",
    },
    {
      question: "Какая гарантия на натяжные потолки?",
      answer: "NOVA STELYA даёт гарантию 10 лет на плёнку и монтаж.",
    },
    {
      question: "Можно ли устанавливать натяжной потолок в ванной?",
      answer: "Да. Используется влагостойкая ПВХ-плёнка, выдерживает до 100 л воды.",
    },
  ];
}
```

```typescript
// content/city-copy.ts
// City-aware H1, CTA, descriptions — центральне місце

import type { CityConfig } from "@/config/geo-matrix";
import type { Locale, ServiceSlug } from "@/seo/types";

// Відмінкові форми — єдиний реєстр
export const CITY_PHRASES: Record<string, Record<Locale, string>> = {
  kyiv:    { uk: "у Києві",   ru: "в Киеве" },
  dnipro:  { uk: "у Дніпрі", ru: "в Днепре" },
  kharkiv: { uk: "у Харкові", ru: "в Харькове" },
  odesa:   { uk: "в Одесі",   ru: "в Одессе" },
  lviv:    { uk: "у Львові",  ru: "во Львове" },
  // При додаванні міста → додати тут
};

export function getCityPhrase(citySlug: string, locale: Locale): string {
  return CITY_PHRASES[citySlug]?.[locale] ?? "";
}

export function buildCityServiceH1(
  serviceTitle: string,
  city: CityConfig | null,
  locale: Locale,
  price: number,
): string {
  if (!city) {
    return locale === "uk"
      ? `${serviceTitle} — від ${price} грн/м²`
      : `${serviceTitle} — от ${price} грн/м²`;
  }

  const phrase = getCityPhrase(city.slug, locale);
  return locale === "uk"
    ? `${serviceTitle} ${phrase} — від ${price} грн/м²`
    : `${serviceTitle} ${phrase} — от ${price} грн/м²`;
}

export function buildCTAText(city: CityConfig | null, locale: Locale): string {
  if (!city) {
    return locale === "uk" ? "Замовити безкоштовний замір" : "Заказать бесплатный замер";
  }
  const phrase = getCityPhrase(city.slug, locale);
  return locale === "uk"
    ? `Замовити замір ${phrase}`
    : `Заказать замер ${phrase}`;
}
```

```typescript
// content/forbidden-patterns.ts
// Що НІКОЛИ не писати в SEO-текстах

export const FORBIDDEN_PATTERNS = [
  // Переспам ключових слів
  /натяжні стелі.{0,20}натяжні стелі/i,
  // Занадто довгий title
  // (перевіряється в audit/)

  // Заборонені фрази
  "дешево",
  "дешевле всех",
  "самые низкие цены",
  "№1 в мире",
] as const;

export const TITLE_RULES = {
  maxLength: 60,
  minLength: 30,
  mustEndWith: "NOVA STELYA",
  mustNotStartWith: ["the", "a ", "і ", "та "],
} as const;

export const DESCRIPTION_RULES = {
  maxLength: 155,
  minLength: 100,
  mustInclude: ["грн/м²", "замір"],
  mustNotInclude: ["!!!", "???"],
} as const;
```

-----

### 3.10 `audit/` — dev-only перевірки

```typescript
// audit/validate-metadata.ts
// Запускається тільки в development — не потрапляє в bundle

import { TITLE_RULES, DESCRIPTION_RULES } from "@/seo/content";

export function validateMetadata(metadata: {
  title?: string;
  description?: string;
  canonical?: string;
}): string[] {
  if (process.env.NODE_ENV !== "development") return [];

  const errors: string[] = [];

  if (metadata.title) {
    if (metadata.title.length > TITLE_RULES.maxLength)
      errors.push(`Title занадто довгий: ${metadata.title.length} > ${TITLE_RULES.maxLength}`);
    if (metadata.title.length < TITLE_RULES.minLength)
      errors.push(`Title занадто короткий: ${metadata.title.length} < ${TITLE_RULES.minLength}`);
  }

  if (metadata.description) {
    if (metadata.description.length > DESCRIPTION_RULES.maxLength)
      errors.push(`Description занадто довгий`);
  }

  if (!metadata.canonical)
    errors.push("Відсутній canonical URL");

  return errors;
}
```

-----

## 4. PUBLIC API — index.ts

```typescript
// src/seo/index.ts
// ← ЄДИНА ТОЧКА ІМПОРТУ ДЛЯ ВСЬОГО ПРОЕКТУ
// В app/ використовувати тільки: import { ... } from "@/seo"

// Metadata
export { generatePageMetadata } from "./metadata/generate-page-metadata";

// Schema
export { getPageSchema } from "./schema/page-schemas";
export { JsonLd } from "./schema/inject/jsonld";

// Sitemap
export { generateSitemap } from "./sitemap/generate-sitemap";

// Robots
export { generateRobots } from "./robots/generate-robots";

// Geo
export { GeoMetaTags } from "./geo/geo-tags";
export { buildServiceArea } from "./geo/local-seo";

// Content
export { getServiceFAQ } from "./content/faq-rules";
export { buildCityServiceH1, buildCTAText, getCityPhrase } from "./content/city-copy";

// Types (реекспорт для зручності)
export type { SeoContext, PageType, Locale, ServiceSlug } from "./types";
```

-----

## 5. ПРАВИЛА ВИКОРИСТАННЯ В app/

### Правило №1: Тільки через Public API

```typescript
// ✅ ПРАВИЛЬНО
import { generatePageMetadata, getPageSchema, JsonLd } from "@/seo";

// ❌ ЗАБОРОНЕНО — прямий імпорт внутрішніх файлів
import { buildTitle } from "@/seo/metadata/core";
import { buildHreflangAlternates } from "@/seo/alternates/build-hreflang";
```

### Правило №2: generateMetadata в кожному page.tsx

```typescript
// app/[locale]/[city]/[service]/page.tsx

import { generatePageMetadata, getPageSchema, JsonLd, getServiceFAQ } from "@/seo";
import { getCityBySlug } from "@/config/geo-matrix";

export async function generateMetadata({ params }): Promise<Metadata> {
  return generatePageMetadata({
    pageType: "city-service",
    locale: params.locale,
    city: getCityBySlug(params.city),
    serviceSlug: params.service,
    basePrice: 280,
  });
}

export default function CityServicePage({ params }) {
  const city = getCityBySlug(params.city);
  const faq = getServiceFAQ(params.service, params.locale, city, 280);
  const schema = getPageSchema({
    pageType: "city-service",
    city,
    breadcrumbs: [...],
    faqItems: faq,
  });

  return (
    <>
      <JsonLd schema={schema} />
      {/* сторінка */}
    </>
  );
}
```

### Правило №3: Ніякого SEO-коду поза src/seo/

```
❌ Заборонено:
app/page.tsx           — SEO логіка
components/SeoHead.tsx — SEO компонент
lib/metadata.ts        — SEO функція
utils/canonical.ts     — SEO утиліта

✅ Дозволено:
src/seo/               — ВСЕ SEO тут
```

-----

## 6. ТИПИ

Всі типи в `src/seo/types/`.
TypeScript strict mode — обов’язково.
Ніяких `any`.

-----

## 7. КОНСТАНТИ

Ієрархія:

```
SITE_URL     → constants/site.ts
LOCALES      → constants/locales.ts
SEO_DEFAULTS → constants/seo-defaults.ts
ROUTES       → constants/routes.ts
```

Ніяких хардкодованих URL або рядків поза `constants/`.

-----

## 8. ЧЕКЛИСТ ЯКОСТІ SEO ПЛАТФОРМИ

**Архітектура:**

- [ ] Весь SEO-код знаходиться в `src/seo/`
- [ ] Імпорти тільки через `src/seo/index.ts`
- [ ] Ніяких прямих імпортів внутрішніх файлів
- [ ] Всі типи типізовані (strict, no any)

**Metadata:**

- [ ] `generatePageMetadata()` викликається в кожному `page.tsx`
- [ ] Кожна сторінка має унікальні title та description
- [ ] Title: 30–60 символів
- [ ] Description: 100–155 символів
- [ ] Canonical URL на кожній сторінці
- [ ] hreflang **uk-UA** ↔ **ru-UA** ↔ x-default на кожній сторінці

**Schema:**

- [ ] JSON-LD присутній на кожній сторінці
- [ ] `@graph` формат (не окремі скрипти)
- [ ] LocalBusiness для кожного міста з координатами
- [ ] FAQPage де є FAQ
- [ ] BreadcrumbList на всіх сторінках

**Sitemap:**

- [ ] 100% активних URL включено
- [ ] `city-service-routes.ts` покриває всі комбінації
- [ ] alternates.languages в кожному записі
- [ ] priority та changeFrequency виставлені правильно

**Content:**

- [ ] FAQ без city-спаму (місто тільки в ціні/телефоні)
- [ ] H1 унікальний per місто через `city-copy.ts`
- [ ] Forbidden patterns не використовуються
- [ ] Відмінкові форми міст у `CITY_PHRASES`

-----

*SEO Platform Layer v2.0 FINAL*
*NOVA STELYA · Next.js 16.2+ · Gold Standard 2026*


📘 SEO PLATFORM LAYER — TECHNICAL SPECIFICATION v3.0
Enterprise SEO Operating System for Next.js 16+

1. ЦЕЛЬ ДОКУМЕНТА
Данный документ описывает полноценный SEO Platform Layer, который:
* централизованно управляет SEO всего сайта
* исключает ручные и хаотичные SEO-решения
* обеспечивает детерминированность, воспроизводимость и масштабируемость
* превращает SEO из «настроек» в инженерную систему

2. ПРОБЛЕМЫ, КОТОРЫЕ РЕШАЕТ ПЛАТФОРМА
❌ SEO размазано по page.tsx❌ Неконтролируемые title / description❌ Ошибки canonical / hreflang❌ Schema ломается незаметно❌ Нет регресс-контроля❌ Невозможно понять, почему SEO такое
✅ SEO Platform Layer решает это системно

3. БАЗОВЫЕ ПРИНЦИПЫ (NON-NEGOTIABLE)
1. SEO = код, а не контент
2. Детерминированность
3. Один источник истины
4. Explainability по умолчанию
5. Guards > warnings
6. SEO — контракт, а не best-effort

4. АРХИТЕКТУРА (ВЫСОКОУРОВНЕВАЯ)

SeoContext
  ↓
Guards
  ↓
Fallbacks
  ↓
SEO Audit Layer
  ↓
Explainability API
  ↓
Hreflang Engine
  ↓
Schema Graph Validator
  ↓
Sitemap Platform
  ↓
Local SEO Engine
  ↓
SEO Content Rules Engine
  ↓
Snapshot SEO Testing


5. SeoContext (CORE)
Назначение:Единый объект, описывающий SEO-сущность страницы.

type SeoContext = {
  locale: "uk-UA" | "ru-UA";
  pageType: "home" | "service" | "cityService";
  serviceSlug?: string;
  city?: {
    slug: string;
    name: string;
  };
  url: string;
};


6. Guards Layer
Назначение:Останавливает билд / рендер при критических SEO-ошибках.
Примеры Guards:
* отсутствует canonical
* canonical ≠ URL страницы
* noindex + sitemap
* hreflang без canonical
📌 Guards = hard fail

7. Fallbacks Layer
Назначение:Безопасная деградация в production.
* fallback title
* fallback description
* fallback canonical
* fallback hreflang
📌 Fallback ≠ silence, fallback = осознанное решение

8. SEO Audit Layer
Назначение:Проверяет качество SEO перед рендером.
Проверки:
* длина title / description
* дубликаты
* consistency metadata ↔ schema
* canonical / alternates alignment
📌 Audit = quality gate

9. Explainability API
Назначение:Понимание почему SEO именно такое.

explainSeo(ctx) => {
  title: { value, rule, source }
  description: { value, rule }
  canonical: { value, rule }
  hreflang: { locales, rule }
  schema: { types, version }
}

📌 Только DEV / STAGING

10. Hreflang / Alternates Engine
Назначение:Единый движок локалей.
Требования:
* x-default обязателен
* canonical ∈ alternates
* строгая локаль ↔ URL
* используется и в metadata, и в sitemap

11. Schema Graph Validator
Назначение:Контроль структуры schema.org.
Функции:
* один <script type="application/ld+json">
* @graph validation
* pageType → allowed schema types
* versioning schema
📌 Ошибка schema = SEO error

12. Sitemap Platform
Назначение:Sitemap как отражение SEO-реальности.
Функции:
* sitemap index
* matrix pages
* исключение noindex
* canonical === sitemap URL
* hreflang completeness

13. Local SEO Engine
Назначение:Масштабируемый Local SEO без спама.
Функции:
* LocalBusiness per city
* ServiceArea rules
* geo-guards
* склонения городов (UA / RU)
📌 Rule-based, не контент-based

14. SEO Content Rules Engine
Назначение:Генерация SEO-контента по правилам.
Что генерируется:
* title
* description
* h1
* intro
* faq
Ограничения:
* ❌ ручные SEO-тексты в страницах
* ❌ keyword stuffing
* ❌ city stuffing
Компоненты:
* Templates
* Rules
* Guards
* Explainability

15. Snapshot SEO Testing
Назначение:Защита SEO от регрессий.
Snapshot включает:
* metadata
* canonical
* hreflang
* open graph
* schema hash
Поведение:
* любое отличие → CI FAIL
* изменения только осознанно
* snapshots = SEO контракт

16. DEV FLOW

Изменение SEO логики
  ↓
Snapshot тест падает
  ↓
Смотрим diff
  ↓
Ожидаемо → обновляем snapshot
Не ожидаемо → фикс баг


17. ЗАПРЕТЫ (HARD RULES)
❌ SEO логика в page.tsx❌ useHead / manual meta❌ CMS-SEO без rules❌ Неконтролируемые schema❌ SEO без explainability

18. РЕЗУЛЬТАТ
В результате реализации SEO Platform Layer v3.0 проект получает:
✅ SEO Operating System✅ Масштабируемость на 100k+ страниц✅ Контроль качества✅ Zero SEO chaos✅ Предсказуемый рост

19. ОПЦИОНАЛЬНЫЕ EXTENSIONS (v4+)
* SEO Feature Flags
* SEO Change Log
* GSC Drift Detection
* SEO Release Notes Generator
* SEO Diff UI

—————————————————————————————————————————

