# NOVA STELYA — План реализации (FINAL) Здесь Учтены Все ошибки и опечатки которые были в двух предыдущих файлах если учтены не все то говори и задавай вопросы будем дорабатывать

> Все решения утверждены. Реализация начата.

## Утверждённые решения

| Вопрос | Решение |
|--------|---------|
| Next.js | **16.x** (последняя стабильная) |
| trailingSlash | **false** — везде, без исключений |
| SEO-структура | **`src/seo/`** — единственная |
| Sanity CMS | Заложить фундамент, не интегрировать |
| PostgreSQL | Заложить фундамент, не использовать |
| Изображения CDN | **Cloudinary** (единый пайплайн) |
| Дизайн | Премиум минимализм, лучший на рынке |
| Страница "О компании" | Да |
| Поиск | Нет |
| Cookie consent | Да, с toggle в коде |
| Контент | Заполнить реалистичным демо-контентом |
| Тесты | Playwright E2E + Vitest unit |

---

## Фаза 0: Фундамент

### [NEW] Инициализация проекта
- `next.config.ts`, `tsconfig.json`, `package.json`
- ESLint + Prettier
- Env validation

### [NEW] Конфигурации
- `src/config/geo-matrix.ts` — с build-time валидацией reserved slugs
- `src/config/services.config.ts` — все 17 услуг
- `src/config/locales.config.ts`
- `src/config/seo.config.ts`
- `src/config/page-blocks.config.ts`
- `i18n.config.ts`

### [NEW] CSS Design System
- CSS custom properties (tokens)
- Reset + layers
- Spacing system (--space-2xs..xl)
- Typography scale
- Color palette (premium dark + light)
- Component base styles

---

## Фаза 1: Ядро

### [NEW] SEO инфраструктура (`src/seo/`)
- `metadata.ts` — generatePageMetadata + canonical + hreflang
- `schema/` — все JSON-LD фабрики
- `sitemap.ts`, `robots.ts`
- `geo.ts`, `constants.ts`, `index.ts`

### [NEW] i18n + Middleware
- `middleware.ts` — next-intl + город cookie + бот-детекция
- `src/messages/uk.json`, `ru.json`
- `src/lib/i18n.ts`, `src/lib/routes.ts`

### [NEW] Layout + UI компоненты
- Header, Footer, Breadcrumb, CityBanner
- Button, Card, Badge, Input, Modal
- Root layout + locale layout + not-found

---

## Фаза 2: Страницы

- Главная (Hero, CatalogGrid, Benefits, CTA)
- 17 страниц услуг (все route groups)
- City Hub + City×Service (generateStaticParams)
- Прайс, FAQ, Контакты, О компании
- City-specific: prices, portfolio, faq

---

## Фаза 3: Интерактив + API

- Калькулятор (Client Component)
- Форма заявки + Zod валидация
- API: contact → Telegram
- API: revalidate webhook (заглушка для Sanity)
- API: geo detection
- Rate limiting (Upstash)
- Cookie consent (toggle)

---

## Фаза 4: Финализация

- Портфолио страницы (с демо-данными)
- Блог страницы (с демо-данными)
- Performance оптимизация
- E2E тесты (Playwright)
- Unit тесты (Vitest)
- Sentry (заглушка)
- Финальный SEO аудит

## Верификация

### Автоматические тесты
- `npx playwright test` — E2E критических потоков
- `npx vitest` — unit для SEO-функций
- `npm run build` — TypeScript strict, без ошибок

### Ручная верификация
- Lighthouse Mobile ≥ 98
- Rich Results Test — все Schema валидны
- hreflang checker
- sitemap валидация
