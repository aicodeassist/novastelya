# NOVA STELYA — AI PROMPT (QUICK START)

> Передай цей файл + NOVA_STELYA_TZ.md будь-якому AI для початку розробки

-----

## КОНТЕКСТ ПРОЄКТУ

Розробка сайту **NOVA STELYA** — компанія з натяжних стель.  
Мультимовний (uk/ru) + мультирегіональний (міста України).  
**Пріоритет №1: SEO** (технічне + контентне + GEO/AEO для AI-пошуку).

-----

## СТЕК

```
Next.js 16+ · App Router · TypeScript · Vanilla CSS only
next-intl · Sanity CMS · Vercel Edge · Cloudflare CDN 
```

-----

## КЛЮЧОВІ ПРАВИЛА (не порушувати)
1. SEO-first + Semantic-first + Accessibility-first + Performance-first
1. `trailingSlash: false` — всі URL Без слеша
1. Українська мова = без префікса `/`, Російська = `/ru`
1. Місто в cookie (НЕ localStorage)
1. RSC за замовчуванням, `"use client"` тільки для інтерактиву
1. Всі дані міст — тільки з `geo-matrix.ts`
1. `generateStaticParams` замість catch-all роутів

-----

## СТРУКТУРА URL

```
/                           → Головна (uk)
/matte-ceilings            → Послуга (uk)
/kyiv                      → Місто-хаб (uk)
/kyiv/matte-ceilings       → Місто × Послуга (uk)
/ru                        → Головна (ru)
/ru/matte-ceilings         → Послуга (ru)
/ru/kyiv/matte-ceilings    → Місто × Послуга (ru)
```

-----

## ДОДАТИ НОВЕ МІСТО = 1 ОБ’ЄКТ

```typescript
// src/config/geo-matrix.ts
{ slug: "lviv", uk: "Львів", ru: "Львов", active: true, ... }
// ВСЕ генерується автоматично
```

-----

## ПОВНЕ ТЗ

Детальна специфікація: `NOVA_STELYA_TZ.md`

Розділи:

- Технологічний стек
- Файлова структура Next.js (повна)
- geo-matrix.ts з прикладом коду
- SEO Metadata API (generatePageMetadata)
- Schema.org JSON-LD для кожного типу сторінки
- Sitemap + Robots автогенерація
- i18n конфігурація + middleware
- City-in-a-Box система
- Performance targets (LCP < 1.2s, INP < 50ms)
- GEO/AEO оптимізація для Gemini/GPT
- Acceptance Criteria (чеклист здачі)
- Що НЕ робити

-----

*NOVA STELYA · Gold Standard 2026 · Next.js 16+*